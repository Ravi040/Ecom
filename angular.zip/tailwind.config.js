/** @type {import('tailwindcss').Config} */
export default {
    content: [
      "./src/**/*.{html,ts}" // Scan all HTML and TypeScript files in the src directory
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  };
  