import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-header',
  imports: [],
  template: `
    
    <div class="header" >{{title()}}</div>   <!--interpolation -->
    
  `,
  styles: `
  .header{
    background-color:hsl(210, 43.50%, 63.90%); 
    color: #ffffff; 
    padding: 1rem; 
  }
  
  
  `
})
export class HeaderComponent {
  title=signal('Angular Ecommerce')

}
